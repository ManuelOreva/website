<?php
// To
define("WEBMASTER_EMAIL", ‘narcissanida@hotmail.com’);
?>